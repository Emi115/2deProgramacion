export function pingController(req, res) {
    res.send('pong');
}
