import logger from './logger.js';

export default logger;